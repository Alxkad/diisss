// server.js

const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 4000;
const LICENSE_FILE = path.join(__dirname, 'licenses.json');

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true
}));

const USER_CREDENTIALS = {
    username: 'admin',
    password: 'password'
};

// Read and write license data
const readLicenses = () => {
    if (!fs.existsSync(LICENSE_FILE)) {
        fs.writeFileSync(LICENSE_FILE, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(LICENSE_FILE, 'utf8'));
};

const writeLicenses = (licenses) => {
    fs.writeFileSync(LICENSE_FILE, JSON.stringify(licenses, null, 2));
};

// Middleware to check if admin is logged in (for web access)
const checkAuth = (req, res, next) => {
    if (req.session && req.session.authenticated) {
        next();
    } else {
        res.status(401).json({ success: false, error: 'Unauthorized' });
    }
};

// Admin login for web interface
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (username === USER_CREDENTIALS.username && password === USER_CREDENTIALS.password) {
        req.session.authenticated = true;
        res.json({ success: true });
    } else {
        res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
});

// License route accessible to the client-side app (no login required)
app.get('/license/:userId', (req, res) => {
    const { userId } = req.params;
    const licenses = readLicenses();
    const license = licenses[userId];

    if (license) {
        res.json({
            success: true,
            limit: license.limit,
            sent: license.sent,
            remaining: license.limit - license.sent
        });
    } else {
        res.status(404).json({ error: 'License not found' });
    }
});

// Admin-only routes (web interface requires login)
app.get('/licenses', checkAuth, (req, res) => {
    const licenses = readLicenses();
    const response = {};
    for (const [userId, license] of Object.entries(licenses)) {
        response[userId] = {
            limit: license.limit,
            sent: license.sent,
            remaining: license.limit - license.sent
        };
    }
    res.json({ success: true, licenses: response });
});

app.post('/license/:userId', checkAuth, (req, res) => {
    const { userId } = req.params;
    const { limit } = req.body;

    if (typeof limit !== 'number' || limit <= 0) {
        return res.status(400).json({ error: 'Invalid limit' });
    }

    const licenses = readLicenses();
    licenses[userId] = { limit, sent: 0 };
    writeLicenses(licenses);

    res.json({ success: true, userId, limit });
});

app.post('/license/:userId/update', checkAuth, (req, res) => {
    const { userId } = req.params;
    const { sent } = req.body;

    if (typeof sent !== 'number' || sent <= 0) {
        return res.status(400).json({ error: 'Invalid sent count' });
    }

    const licenses = readLicenses();
    const license = licenses[userId];

    if (license) {
        license.sent += sent;
        writeLicenses(licenses);
        res.json({
            success: true,
            limit: license.limit,
            sent: license.sent,
            remaining: license.limit - license.sent
        });
    } else {
        res.status(404).json({ error: 'License not found' });
    }
});

// Listen to the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
